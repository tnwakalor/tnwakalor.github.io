<!-- jQuery call to the accordion() method. -->
$(document).ready(function() {
    $("#tabs").tabs();
});